#include <ros/ros.h>

#include <unitree/robot/channel/channel_factory.hpp>
#include <unitree/robot/go2/sport/sport_client.hpp>

int main(int argc, char** argv)
{
    ros::init(argc, argv, "mode_switch_node");
    ros::NodeHandle nh("~");

    std::string network_interface;
    nh.param<std::string>(
        "network_interface",
        network_interface,
        "eth0"
    );

    ROS_INFO("Network interface: %s",
             network_interface.c_str());

    unitree::robot::ChannelFactory::Instance()->Init(
        0,
        network_interface
    );

    unitree::robot::go2::SportClient sport_client;

    sport_client.SetTimeout(10.0f);
    sport_client.Init();

    ROS_INFO("Unitree SportClient initialized.");

    int ret;

    ret = sport_client.StopMove();
    ROS_INFO("StopMove ret = %d", ret);
    
    ros::Duration(0.5).sleep();
    ret = sport_client.SwitchGait(0);
    ROS_INFO("SwitchGait(0) ret = %d", ret);
    
    ros::Duration(2.0).sleep();

    ret = sport_client.SwitchGait(1);
    ROS_INFO("SwitchGait(1) ret = %d", ret);
    
    ros::Duration(2.0).sleep();

    ret = sport_client.SwitchGait(2);
    ROS_INFO("SwitchGait(2) ret = %d", ret);
    
    ros::Duration(2.0).sleep();
    
    
    // ret = sport_client.FreeWalk();
    // ROS_INFO("FreeWalk ret = %d", ret);

    return 0;
}