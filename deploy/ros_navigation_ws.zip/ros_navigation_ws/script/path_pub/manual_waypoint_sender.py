#!/usr/bin/env python3
import math

import actionlib
import rospy
from actionlib_msgs.msg import GoalStatus
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal


# x, y, yaw（角度）
WAYPOINTS = [
    (-38.741147, 72.585418, -68.012611),
    (-35.935962, 62.813723, -77.787329),
    (-33.300853, 52.723518, -71.945394),
    (-33.700147, 31.755942, -85.596400),
    (-32.515560, 21.224434, -89.306874),
    (-23.980498, 1.697964, -54.840827),
    (-21.156102, -1.506198, -19.589083),
    (-9.918127, -0.256677, 5.956584),
    (0.743136, 2.057120, 11.448384),
    (10.843032, 3.505432, 5.518386),
    (21.255146, 3.671874, -0.084110),
    (30.382646, 3.341202, 35.994756),
    (37.586928, 11.195861, 67.746759),
    (38.720200, 29.966500, 171.887339),
    (31.277100, 32.299900, 179.908748),
    (21.244800, 31.971000, 179.908748),
    (2.860000, 30.400000, 100.984653),
    (21.244800, 31.971000, 0.000000),
    (31.277100, 32.299900, 0.000000),
    (43.293351, 51.077644, 93.182189),
    (45.548135, 61.379861, 72.642110),
    (47.865060, 71.690594, 78.721364),
    (48.889869, 82.185932, 84.819813),
    (50.485221, 92.448211, 74.116159),
    (53.003003, 102.834207, 76.279476),
    (55.749237, 112.804461, 70.712388),
    (56.671374, 121.000000, 93.094183),
    (56.200000, 127.234299, 127.418308),
    (43.156630, 130.549240, 164.327504),
    (32.797340, 131.171726, -173.062876),
    (22.474618, 129.460381, -168.993615),
    (12.313789, 128.876142, -171.948645),
    (6.470000, 130.000000, -86.618384),
    (7.020000, 127.000000, -176.618366),
    (-3.763919, 125.774733, -177.161186),
    (-14.187142, 124.924783, -176.711242),
    (-24.567585, 123.779674, -172.545209),
    (-33.989362, 121.976569, -141.813070),
    (-41.168770, 114.861860, -125.686944),
    (-46.207380, 105.821021, -116.247407),
    (-47.283134, 100.185004, -85.088472),
    (-44.016238, 89.932525, -67.710720),
    (-40.663766, 80.280698, -68.012611),
    (-38.741147, 72.585418, -68.012611),
]


def make_goal(x, y, yaw_deg):
    yaw = math.radians(yaw_deg)
    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "map"
    goal.target_pose.header.stamp = rospy.Time.now()
    goal.target_pose.pose.position.x = x
    goal.target_pose.pose.position.y = y
    goal.target_pose.pose.orientation.z = math.sin(yaw / 2.0)
    goal.target_pose.pose.orientation.w = math.cos(yaw / 2.0)
    return goal


def main():
    rospy.init_node("manual_waypoint_sender")
    client = actionlib.SimpleActionClient("/move_base", MoveBaseAction)

    rospy.loginfo("Waiting for /move_base...")
    client.wait_for_server()

    try:
        for index, (x, y, yaw_deg) in enumerate(WAYPOINTS, start=1):
            answer = input(
                "[{}/{}] x={:.6f}, y={:.6f}, yaw={:.6f} deg; "
                "press Enter to send, or q to quit: ".format(
                    index, len(WAYPOINTS), x, y, yaw_deg
                )
            ).strip().lower()
            if answer == "q":
                break

            client.send_goal(make_goal(x, y, yaw_deg))
            client.wait_for_result()

            state = client.get_state()
            if state == GoalStatus.SUCCEEDED:
                rospy.loginfo("Goal %d reached", index)
            else:
                rospy.logwarn("Goal %d finished with state %d", index, state)
    except (KeyboardInterrupt, rospy.ROSInterruptException):
        client.cancel_goal()


if __name__ == "__main__":
    main()
